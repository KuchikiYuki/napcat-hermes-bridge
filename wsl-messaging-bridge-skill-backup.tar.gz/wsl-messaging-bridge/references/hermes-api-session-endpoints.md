# Hermes API Session Endpoints Reference

Observed response formats for the Hermes Gateway API Server (:8642)
session endpoints. These are not in the Hermes docs and were discovered
by probing with `curl` during bridge debugging.

## Create Session

```
POST /api/sessions
Headers: Authorization: Bearer <KEY>, Content-Type: application/json
Body: {"id": "<desired_id>", "title": "<title>"}
```

Response (201): `{"session": {"id": "<id>", "title": "<title>", ...}}`

The `id` field is optional — if omitted, Hermes generates one in
`YYYYMMDD_HHMMSS_6hex` format (matching TUI session IDs). If provided,
Hermes uses it as-is. Custom prefixes like `qq_` work but produce IDs
that look inconsistent in the TUI sidebar. Use the TUI format for
visual consistency.

## Get Session

```
GET /api/sessions/{SID}
Headers: Authorization: Bearer <KEY>
```

- Response (200): session object
- Response (404): session not found — use this to detect stale sessions

## List Sessions

```
GET /api/sessions
Headers: Authorization: Bearer <KEY>
```

Response format:
```json
{
  "object": "list",
  "data": [
    {
      "id": "20260629_152146_abec9b",
      "source": "tui",
      "title": "...",
      "model": "...",
      "message_count": 62,
      "started_at": 1782717711.69,
      "last_active": 1782718392.09,
      ...
    }
  ]
}
```

**Critical:** The response uses `{"object": "list", "data": [...]}` — NOT
`{"sessions": [...]}` or a bare array. Bridge code must parse
`data.get("data")`, not `data.get("sessions")`.

Session `source` field: `"tui"` for TUI sessions, `"api_server"` for
sessions created via the API.

## Chat (Send Message)

```
POST /api/sessions/{SID}/chat
Headers: Authorization: Bearer <KEY>, Content-Type: application/json
Body: {"message": "<prompt>"}
```

Response (200):
```json
{
  "message": {
    "content": "<agent reply text>",
    ...
  }
}
```

Response (404): session not found — bridge should call `ensure_session()`
to recreate, then retry once.

The response is NOT streaming — the full agent reply is returned in one
JSON body. Timeout should be generous (600s) since agent tool calls can
take minutes.

## Health

```
GET /health
```

Response: `{"status": "ok", "platform": "hermes-agent", ...}`

No auth required. Useful for verifying the Gateway is up before starting
the bridge.
