# WSL Proxy Setup

## Finding the Windows host IP from WSL

WSL2 uses a virtual network adapter. The Windows host is reachable at the
**default gateway** of the WSL virtual interface, NOT at `127.0.0.1` or
`localhost` (those refer to the WSL VM itself).

```bash
# Get the Windows host IP (WSL gateway)
WINHOST=$(ip route | grep default | awk '{print $3}')
echo "Windows host: $WINHOST"
# Typically 172.x.x.1
```

## Common proxy configurations

| VPN/Proxy tool | Listening on | Accessible from WSL? |
|---|---|---|
| Clash for Windows | `127.0.0.1:7890` | ❌ (Windows localhost only) |
| Clash with "Allow LAN" | `0.0.0.0:7890` | ✅ via `WINHOST:7890` |
| V2RayN | `127.0.0.1:<PROXY_PORT>` | ❌ by default, ✅ if "allow LAN" enabled |
| Custom proxy | `<WSL_GATEWAY_IP>:<PROXY_PORT>` | ✅ if bound to the WSL gateway IP |

## Testing connectivity

```bash
WINHOST=$(ip route | grep default | awk '{print $3}')
timeout 10 curl -x "http://$WINHOST:<PROXY_PORT>" -sI "https://pypi.org/simple" | head -3
# HTTP/1.1 200 Connection established → proxy works
```

## Setting proxy for tools

```bash
export HTTP_PROXY="http://$WINHOST:<PROXY_PORT>"
export HTTPS_PROXY="$HTTP_PROXY"
export NO_PROXY="127.0.0.1,localhost"  # CRITICAL: don't proxy localhost!
```

## Pitfalls

- **`/etc/resolv.conf` nameserver is NOT the Windows host IP.** On WSL2 with
  systemd, `resolv.conf` often shows `10.255.255.254` (a DNS forwarder), not
  the actual gateway. Use `ip route` to find the real gateway.
- **Proxy env vars leak into localhost requests.** If `NO_PROXY` is not set,
  curl/aiohttp will route `http://127.0.0.1:8642` through the proxy, getting
  502 Bad Gateway. Always set `NO_PROXY`.
- **NapCat's Node.js HTTP client respects `HTTP_PROXY` but may not respect
  `NO_PROXY` alone.** Even with `NO_PROXY=127.0.0.1` set, NapCat's
  `httpClients` event poster can still route localhost POSTs through
  `HTTP_PROXY` — especially if a VPN uses TUN-mode DNS interception
  (`198.18.0.x` fake IPs). This causes silent event delivery failure: the
  bridge never receives messages and no error appears in logs.
  Fix: BOTH unset the proxy vars AND explicitly set `NO_PROXY` in the child
  environment:
  ```bash
  env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy \
      NO_PROXY="127.0.0.1,localhost,::1" no_proxy="127.0.0.1,localhost,::1" \
      xvfb-run -a ntqq/opt/QQ/qq --no-sandbox ...
  ```
  Set `NO_PROXY` in BOTH uppercase and lowercase (Node.js checks lowercase
  `no_proxy` on some platforms).
- **apt has its own proxy config.** Even if you unset env vars, apt may have a
  stale proxy in `/etc/apt/apt.conf.d/`. Bypass with
  `-o Acquire::http::Proxy=""`.
