# NapCat Configuration Reference

## Account-Specific Config Files

NapCat creates per-account config files on first login that **override** the
generic config files. The pattern is `<config_name>_<QQ_number>.json`.

| Generic file | Account-specific override |
|---|---|
| `onebot11.json` | `onebot11_<YOUR_BOT_QQ>.json` |
| `napcat.json` | `napcat_<YOUR_BOT_QQ>.json` |
| `napcat_protocol.json` | `napcat_protocol_<YOUR_BOT_QQ>.json` |
| `webui.json` | (not overridden — shared) |

**If you change `onebot11.json` after the first login, NapCat will ignore it.**
You must also overwrite the account-specific file:

```bash
cp napcat/config/onebot11.json napcat/config/onebot11_<QQID>.json
```

Then restart NapCat.

## Config Directory Location

NapCat looks for config files in its own `config/` subdirectory, relative to
where `napcat.mjs` lives:

```
~/napcat-astrbot/napcat/config/
├── napcat.json                     # Core NapCat settings (logging, packet, bypass)
├── napcat_<QQID>.json              # Per-account core override
├── onebot11.json                   # OneBot v11 network config (generic)
├── onebot11_<QQID>.json            # Per-account OneBot override ← THE IMPORTANT ONE
├── napcat_protocol_<QQID>.json     # Per-account NapCat Protocol config
└── webui.json                       # WebUI settings (shared)
```

## OneBot v11 HTTP Server Mode

For the Hermes bridge architecture, NapCat should be configured with:

1. **HTTP Server** on port 3000 — for the bridge to call `send_msg` API
2. **HTTP Client** posting to `http://127.0.0.1:8080/onebot` — for event forwarding

```json
{
  "network": {
    "httpServers": [{
      "enable": true, "name": "api",
      "host": "127.0.0.1", "port": 3000,
      "messagePostFormat": "array", "token": "",
      "debug": false, "enableForcePushEvent": true
    }],
    "httpClients": [{
      "enable": true, "name": "bridge",
      "url": "http://127.0.0.1:8080/onebot",
      "messagePostFormat": "array", "reportSelfMessage": false, "token": ""
    }],
    "websocketServers": [],
    "websocketClients": []
  }
}
```

## QQ Version Matching

NapCat releases specify a recommended QQ NTQQ version. Using a mismatched
version produces a warning:

```
[Core] [Packet] PacketBackend 不支持当前QQ版本架构：0.0.1-x64
```

This warning is non-fatal — NapCat still works, but some packet-level
features (like fetching specific message types) may not function. For basic
messaging (send/receive text), it works fine with version mismatches.

## Login Credential Persistence

NTQQ stores login tokens in `~/.config/QQ/`. After the first successful QR
code scan:

- Subsequent NapCat restarts **may** auto-login without a QR code
- Tokens **can expire**, requiring re-scan
- `Login Error, ErrType: 1, ErrCode: 3` means QR code expired (not a real
  error) — NapCat will auto-generate a new QR code

### Quick Login with `-q`

NapCat supports `-q <QQID>` flag for quick login using stored credentials:

```bash
xvfb-run -a ntqq/opt/QQ/qq --no-sandbox --disable-gpu -q <YOUR_BOT_QQ>
```

On startup, NapCat prints available quick-login accounts:
```
可用于快速登录 of QQ：
1. <YOUR_BOT_QQ> 千寻
```

With `-q`, login takes ~15s and skips QR entirely. If tokens have expired,
NapCat falls back to QR scan mode automatically. The `qq-start.sh` template
uses `-q` by default.

## WebUI Token

NapCat's WebUI (`http://localhost:6099/webui`) uses a token for auth. The
token is printed in the console log on startup:

```
[WebUi] WebUi Token: <random-token>
[WebUi] WebUi User Panel Url: http://127.0.0.1:6099/webui?token=<random-token>
```

If the token is set to `"napcat"` in `webui.json`, NapCat will auto-generate
a random secure token on startup and print it in the log. Check with:

```bash
grep "WebUi Token" ~/napcat-astrbot/logs/napcat.log | tail -1
```
