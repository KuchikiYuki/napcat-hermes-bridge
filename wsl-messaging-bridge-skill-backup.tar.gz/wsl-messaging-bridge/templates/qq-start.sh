#!/bin/bash
#
# qq-start.sh — 一键连锁启动 NapCat + Hermes Gateway + Bridge
#
# Usage: ~/napcat-astrbot/qq-start.sh
# Stop:  ~/napcat-astrbot/qq-stop.sh
#
# Customize: EDIT the BASE_DIR, proxy, Windows username, QQ IDs below.
#

set -euo pipefail

BASE_DIR="$HOME/napcat-astrbot"
LOG_DIR="$BASE_DIR/logs"
PID_DIR="$BASE_DIR/pids"
QR_FILE="$BASE_DIR/napcat/cache/qrcode.png"
DESKTOP_QR="/mnt/c/Users/<WIN_USER>/Desktop/napcat-qrcode.png"
QQ_OWNER=<YOUR_OWNER_QQ>          # 大号 QQ，用于发送启动确认消息
QQ_BOT=<YOUR_BOT_QQ>            # 小号 QQ（NapCat 登录账号），用于快速登录
PROXY_HOST="<WSL_GATEWAY_IP>"     # WSL gateway IP
PROXY_PORT="<PROXY_PORT>"           # Proxy port on Windows host
WIN_USER="<WIN_USER>"        # Windows username for QR code copy

mkdir -p "$LOG_DIR" "$PID_DIR"

# ── Proxy: 只给 Hermes Gateway 用，NapCat 不走代理 ──────────────────────────
export HTTPS_PROXY="http://${PROXY_HOST}:${PROXY_PORT}"
export NO_PROXY="127.0.0.1,localhost,::1"
export HOME="${HOME:-/home/yuki}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; CYAN='\033[0;36m'; NC='\033[0m'
log()  { echo -e "${CYAN}[$(date +%H:%M:%S)]${NC} $1"; }
ok()   { echo -e "${GREEN}[$(date +%H:%M:%S)] ✓ $1${NC}"; }
warn() { echo -e "${YELLOW}[$(date +%H:%M:%S)] ⚠ $1${NC}"; }
fail() { echo -e "${RED}[$(date +%H:%M:%S)] ✗ $1${NC}"; exit 1; }

start_gateway() {
    log "Starting Hermes Gateway (API Server :8642)..."
    cd /home/yuki/.hermes/hermes-agent
    nohup ./venv/bin/python -m gateway.run > "$LOG_DIR/gateway.log" 2>&1 &
    echo $! > "$PID_DIR/gateway.pid"
    for i in $(seq 1 15); do
        ss -tlnp 2>/dev/null | grep -q ":8642" && { ok "Hermes Gateway (pid $(cat $PID_DIR/gateway.pid), :8642)"; return 0; }
        sleep 1
    done
    fail "Hermes Gateway failed to start"
}

start_bridge() {
    log "Starting Bridge (:8080)..."
    cd "$BASE_DIR"
    nohup /home/yuki/uv-env/bin/python3 bridge.py > "$LOG_DIR/bridge.log" 2>&1 &
    echo $! > "$PID_DIR/bridge.pid"
    for i in $(seq 1 10); do
        ss -tlnp 2>/dev/null | grep -q ":8080" && { ok "Bridge (pid $(cat $PID_DIR/bridge.pid), :8080)"; return 0; }
        sleep 1
    done
    fail "Bridge failed to start"
}

start_napcat() {
    log "Starting NapCat (NTQQ headless + xvfb)..."
    cd "$BASE_DIR"
    # CRITICAL: Unset ALL proxy env vars AND set NO_PROXY for NapCat.
    # NapCat's internal Node.js HTTP client respects HTTP_PROXY but NOT
    # NO_PROXY — even with NO_PROXY=127.0.0.1 set, it will silently route
    # localhost event POSTs through the proxy (502 Bad Gateway, no error
    # in NapCat logs, bridge never receives events).
    # The NO_PROXY env var must be explicitly set in the child env because
    # env -u only removes from the child, but NapCat's Node.js runtime may
    # still pick up proxy settings from other sources.
    # -q enables quick login using stored credentials (skips QR scan if
    # tokens are still valid). Falls back to QR scan if tokens expired.
    nohup env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy \
        NO_PROXY="127.0.0.1,localhost,::1" no_proxy="127.0.0.1,localhost,::1" \
        xvfb-run -a ntqq/opt/QQ/qq \
        --no-sandbox --disable-gpu --disable-software-rasterizer \
        --disable-zygote --in-process-gpu \
        -q "$QQ_BOT" \
        > "$LOG_DIR/napcat.log" 2>&1 &
    echo $! > "$PID_DIR/napcat.pid"
    for i in $(seq 1 40); do
        ss -tlnp 2>/dev/null | grep -q ":6099" && { ok "NapCat (pid $(cat $PID_DIR/napcat.pid), WebUI :6099)"; return 0; }
        sleep 1
    done
    fail "NapCat failed to start"
}

wait_for_login() {
    log "Waiting for NapCat login..."
    local login_wait=0 max_wait=180 qr_announced=false
    while [ $login_wait -lt $max_wait ]; do
        if ss -tlnp 2>/dev/null | grep -q ":3000"; then
            ok "NapCat login successful! HTTP API is up (:3000)"
            sleep 2
            log "Sending startup confirmation to QQ $QQ_OWNER..."
            local session_id=""
            session_id=$(cat "$BASE_DIR/current_session.txt" 2>/dev/null | head -1 | tr -d '[:space:]')
            local confirm_msg
            if [ -n "$session_id" ]; then
                confirm_msg="🌉 NapCat ↔ Hermes 桥接已上线！发送消息即可与 Hermes Agent 对话。\\n\\n📌 当前会话: $session_id\\n\\n指令: /new /switch <id> /session /list /help"
            else
                confirm_msg="🌉 NapCat ↔ Hermes 桥接已上线！发送消息即可与 Hermes Agent 对话。\\n\\n⚠ 未获取到会话 ID，请检查 Bridge 日志。"
            fi
            local resp
            resp=$(curl --noproxy '*' -s -m 10 -X POST http://127.0.0.1:3000/send_private_msg \
                -H "Content-Type: application/json" \
                -d "{\"user_id\": $QQ_OWNER, \"message\": [{\"type\": \"text\", \"data\": {\"text\": \"$confirm_msg\"}}]}" 2>&1)
            echo "$resp" | grep -q '"status":"ok"' && ok "Confirmation sent to QQ $QQ_OWNER ✓" || warn "Failed to send confirmation: $resp"
            return 0
        fi
        # If QR code appears (quick login failed, fell back to scan mode)
        if [ "$qr_announced" = false ] && [ -f "$QR_FILE" ]; then
            qr_announced=true
            cp "$QR_FILE" "$DESKTOP_QR" 2>/dev/null || true
            log "Quick login failed — QR code required. Copied to Desktop."
            log "WebUI: http://localhost:6099/webui"
            log "请用手机 QQ 扫码登录..."
        fi
        # Re-copy QR if refreshed
        if [ "$qr_announced" = true ] && [ -f "$QR_FILE" ]; then
            local new_qr_time
            new_qr_time=$(stat -c %Y "$QR_FILE" 2>/dev/null || echo 0)
            if [ "${new_qr_time}" != "${last_qr_time:-0}" ]; then
                cp "$QR_FILE" "$DESKTOP_QR" 2>/dev/null || true
                last_qr_time="$new_qr_time"
                log "QR code refreshed. 桌面 napcat-qrcode.png 已更新，请重新扫码"
            fi
        fi
        sleep 3; login_wait=$((login_wait + 3))
        [ $((login_wait % 15)) -eq 0 ] && log "Still waiting... (${login_wait}s / ${max_wait}s)"
    done
    warn "Login timeout after ${max_wait}s."
    return 1
}

echo ""
echo "  ╔═════════════════════════════════════════════════════╗"
echo "  ║   NapCat ↔ Hermes Agent — 一键连锁启动             ║"
echo "  ║   扫码登录后自动发 QQ 确认消息                      ║"
echo "  ╚═════════════════════════════════════════════════════╝"
echo ""

pkill -f "gateway.run" 2>/dev/null || true
pkill -f "bridge.py" 2>/dev/null || true
pkill -f "ntqq/opt/QQ/qq" 2>/dev/null || true
pkill -f "xvfb-run.*ntqq" 2>/dev/null || true
sleep 2

start_gateway; sleep 1
start_bridge;  sleep 1
start_napcat
wait_for_login

echo ""
ok "All services are up!"
echo "  Hermes API :8642 | Bridge :8080 | NapCat WebUI :6099 | NapCat API :3000"
echo "  Logs: $LOG_DIR/"
echo "  Stop: ~/napcat-astrbot/qq-stop.sh"
echo ""
