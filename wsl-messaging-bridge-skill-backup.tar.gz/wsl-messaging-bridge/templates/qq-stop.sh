#!/bin/bash
# qq-stop.sh — Stop all QQ bridge services
PID_DIR="$HOME/napcat-astrbot/pids"

ok() { echo -e "\033[0;32m[$(date +%H:%M:%S)] ✓ $1\033[0m"; }

echo "Stopping all QQ services..."
for svc in napcat bridge gateway; do
    [ -f "$PID_DIR/$svc.pid" ] && kill "$(cat $PID_DIR/$svc.pid)" 2>/dev/null && rm -f "$PID_DIR/$svc.pid"
done
pkill -f "ntqq/opt/QQ/qq" 2>/dev/null || true
pkill -f "bridge.py" 2>/dev/null || true
pkill -f "gateway.run" 2>/dev/null || true
sleep 2
ok "All services stopped."
