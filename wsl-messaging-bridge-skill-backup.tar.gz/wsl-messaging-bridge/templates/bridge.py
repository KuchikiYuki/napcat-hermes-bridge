#!/usr/bin/env python3
"""
NapCat ↔ Hermes Bridge v3

Session management:
- Each chain startup creates a FRESH Hermes session (avoids cross-contamination)
- Session ID persisted to file, survives bridge restarts within same chain run
- QQ commands: /new /switch <id> /session /list /help
- 404 auto-recovery: if session disappears mid-conversation, recreate + retry

Architecture:
    QQ消息 → NapCat → POST :8080/onebot → bridge.py
                                        ↓ ACK → QQ
                                        ↓ /api/sessions/{SID}/chat → Hermes API (:8642)
    QQ回复 ← NapCat HTTP API (:3000) ← bridge.py ← final response

Requires: aiohttp

Usage:
    HERMES_API_KEY=*** ALLOWED_QQ=<YOUR_OWNER_QQ> python3 bridge.py
"""

import asyncio
import json
import logging
import os
import time
from typing import Any, Optional

from aiohttp import web, ClientSession, ClientTimeout

# ── Config ──────────────────────────────────────────────────────────────────
NAPCAT_API = "http://127.0.0.1:3000"
HERMES_API = "http://127.0.0.1:8642"
HERMES_KEY = os.environ.get("HERMES_API_KEY", "<your-api-key>")
BRIDGE_HOST = "127.0.0.1"
BRIDGE_PORT = 8080
ALLOWED_QQ = int(os.environ.get("ALLOWED_QQ", "0"))

# Session persistence: store in file so it survives bridge restarts
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SESSION_FILE = os.path.join(SCRIPT_DIR, "current_session.txt")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("bridge")

# ── Session persistence helpers ─────────────────────────────────────────────

def load_session_id() -> str:
    """Load session ID from persistence file. Returns empty string if none."""
    try:
        with open(SESSION_FILE, "r") as f:
            return f.read().strip()
    except (FileNotFoundError, IOError):
        return ""

def save_session_id(sid: str) -> None:
    """Persist session ID to file."""
    try:
        with open(SESSION_FILE, "w") as f:
            f.write(sid)
    except IOError as e:
        log.warning(f"Failed to save session ID: {e}")

# ── Session management ──────────────────────────────────────────────────────

async def create_session(sid: str = None, title: str = None) -> str:
    """Create a new Hermes session. Returns the session ID."""
    headers = {"Authorization": f"Bearer {HERMES_KEY}", "Content-Type": "application/json"}
    if sid is None:
        # Match Hermes TUI format: YYYYMMDD_HHMMSS_6hex
        sid = time.strftime("%Y%m%d_%H%M%S") + "_" + os.urandom(3).hex()
    if title is None:
        title = f"QQ Bridge {time.strftime('%Y-%m-%d %H:%M')}"

    try:
        async with ClientSession(trust_env=False) as session:
            async with session.post(
                f"{HERMES_API}/api/sessions",
                headers=headers,
                json={"id": sid, "title": title},
                timeout=ClientTimeout(total=10),
            ) as resp:
                if resp.status in (200, 201):
                    data = await resp.json()
                    created_sid = data.get("session", {}).get("id", sid)
                    log.info(f"Session created: {created_sid}")
                    return created_sid
                else:
                    text = await resp.text()
                    log.warning(f"Session create returned {resp.status}: {text[:200]}")
                    return sid
    except Exception as e:
        log.warning(f"Session create failed ({e}), using {sid}")
        return sid

async def ensure_session(sid: str) -> str:
    """Verify a session exists. If not, create it with the same ID. Return its ID."""
    headers = {"Authorization": f"Bearer {HERMES_KEY}"}
    try:
        async with ClientSession(trust_env=False) as session:
            async with session.get(
                f"{HERMES_API}/api/sessions/{sid}",
                headers=headers,
                timeout=ClientTimeout(total=10),
            ) as resp:
                if resp.status == 200:
                    log.info(f"Session exists: {sid}")
                    return sid
    except Exception:
        pass
    log.info(f"Session {sid} not found, creating...")
    return await create_session(sid)

async def list_sessions() -> list[dict]:
    """List all sessions from Hermes API."""
    headers = {"Authorization": f"Bearer {HERMES_KEY}"}
    try:
        async with ClientSession(trust_env=False) as session:
            async with session.get(
                f"{HERMES_API}/api/sessions",
                headers=headers,
                timeout=ClientTimeout(total=10),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    # API returns {"object": "list", "data": [...]}
                    if isinstance(data, dict):
                        sessions = data.get("data") or data.get("sessions") or []
                    else:
                        sessions = data
                    return sessions if isinstance(sessions, list) else []
                return []
    except Exception as e:
        log.error(f"Failed to list sessions: {e}")
        return []

# ── QQ helpers ──────────────────────────────────────────────────────────────

def extract_text(message: list[dict] | str) -> str:
    if isinstance(message, str):
        return message
    parts = []
    for seg in message:
        t = seg.get("type", "")
        if t == "text":
            parts.append(seg.get("data", {}).get("text", ""))
        elif t == "image":
            parts.append("[图片]")
        elif t == "face":
            parts.append("[表情]")
        elif t == "record":
            parts.append("[语音]")
        elif t == "video":
            parts.append("[视频]")
        elif t == "file":
            parts.append(f"[文件:{seg.get('data',{}).get('file','')}]")
    return "".join(parts).strip()

async def send_to_qq(message_type: str, target_id: int, text: str) -> bool:
    """Send a message via NapCat HTTP API. Returns True on success."""
    endpoint = f"{NAPCAT_API}/send_{message_type}_msg"
    params = {
        "message_type": message_type,
        "message": [{"type": "text", "data": {"text": text}}],
    }
    if message_type == "private":
        params["user_id"] = target_id
    else:
        params["group_id"] = target_id
    try:
        async with ClientSession(trust_env=False) as session:
            async with session.post(endpoint, json=params, timeout=ClientTimeout(total=30)) as resp:
                result = await resp.json()
                return result.get("status") == "ok"
    except Exception as e:
        log.error(f"Failed to send to QQ: {e}")
        return False

# ── Hermes API call ─────────────────────────────────────────────────────────

PERSISTENT_SID: str = ""

async def call_hermes_session(prompt: str, session_id: str) -> str:
    """Call Hermes session chat endpoint. Auto-recovers from 404."""
    global PERSISTENT_SID
    headers = {"Authorization": f"Bearer {HERMES_KEY}", "Content-Type": "application/json"}
    payload = {"message": prompt}

    async def _do_chat(sid: str) -> tuple[int, str]:
        async with ClientSession(trust_env=False) as session:
            async with session.post(
                f"{HERMES_API}/api/sessions/{sid}/chat",
                headers=headers,
                json=payload,
                timeout=ClientTimeout(total=600),
            ) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    return resp.status, f"[Hermes API 错误 {resp.status}: {error_text[:100]}]"
                data = await resp.json()
                return 200, data.get("message", {}).get("content", "[空回复]")

    try:
        status, text = await _do_chat(session_id)
        if status == 404:
            log.warning(f"Session {session_id} not found (404), recreating...")
            new_sid = await ensure_session(session_id)
            PERSISTENT_SID = new_sid
            save_session_id(new_sid)
            log.info(f"Session recreated: {new_sid}, retrying chat...")
            status, text = await _do_chat(new_sid)
        return text
    except Exception as e:
        log.error(f"Failed to call Hermes session API: {e}")
        return f"[调用 Hermes 失败: {e}]"

# ── Bridge commands ─────────────────────────────────────────────────────────

async def handle_bridge_command(text: str) -> Optional[str]:
    """Handle bridge-level QQ commands. Returns response text or None if not a command."""
    global PERSISTENT_SID
    cmd_parts = text.strip().split()
    if not cmd_parts:
        return None
    command = cmd_parts[0].lower()

    if command == "/new":
        new_sid = await create_session()
        PERSISTENT_SID = new_sid
        save_session_id(new_sid)
        return f"✅ 已创建新会话: {new_sid}\n之前的历史将不再可见。"

    elif command == "/switch" and len(cmd_parts) > 1:
        target_sid = cmd_parts[1]
        headers = {"Authorization": f"Bearer {HERMES_KEY}"}
        try:
            async with ClientSession(trust_env=False) as session:
                async with session.get(
                    f"{HERMES_API}/api/sessions/{target_sid}",
                    headers=headers,
                    timeout=ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        PERSISTENT_SID = target_sid
                        save_session_id(target_sid)
                        return f"✅ 已切换到会话: {target_sid}"
                    else:
                        return f"❌ 会话 {target_sid} 不存在 (HTTP {resp.status})"
        except Exception as e:
            return f"❌ 切换会话失败: {e}"

    elif command == "/session":
        return f"📌 当前会话: {PERSISTENT_SID}"

    elif command == "/list":
        sessions = await list_sessions()
        if not sessions:
            return "📋 没有找到会话列表"
        lines = ["📋 可用会话:"]
        for s in sessions[:20]:
            sid = s.get("id", "?")
            title = s.get("title", "")
            marker = " ← 当前" if sid == PERSISTENT_SID else ""
            lines.append(f"  • {sid}  ({title}){marker}")
        return "\n".join(lines)

    elif command == "/help":
        return (
            "🌉 Bridge 指令:\n"
            "  /new         — 开启新会话（清除上下文）\n"
            "  /switch <id> — 切换到指定会话\n"
            "  /session     — 显示当前会话 ID\n"
            "  /list        — 列出所有会话\n"
            "  /help        — 显示此帮助\n"
            "其他消息将直接发给 Hermes Agent 对话。"
        )

    return None

# ── Event Handler ────────────────────────────────────────────────────────────

async def handle_onebot_event(request: web.Request) -> web.Response:
    try:
        event = await request.json()
    except Exception:
        return web.Response(status=400, text="Invalid JSON")

    post_type = event.get("post_type", "")
    if post_type != "message":
        return web.json_response({"status": "ok", "ignored": True})

    message_type = event.get("message_type", "")
    user_id = event.get("user_id", 0)
    group_id = event.get("group_id", 0)
    sender = event.get("sender", {})
    sender_name = sender.get("nickname", str(user_id))
    text = extract_text(event.get("message", ""))

    if not text:
        return web.json_response({"status": "ok", "ignored": "empty"})

    if ALLOWED_QQ and user_id != ALLOWED_QQ:
        log.info(f"🚫 Ignored message from {sender_name}({user_id}) — not owner")
        return web.json_response({"status": "ok", "ignored": "not_owner"})

    if message_type == "group":
        target_id = group_id
        reply_type = "group"
        log.info(f"📨 Group {group_id} | {sender_name}({user_id}): {text[:100]}")
    else:
        target_id = user_id
        reply_type = "private"
        log.info(f"📨 Private | {sender_name}({user_id}): {text[:100]}")

    # Check for bridge commands (/new, /switch, /session, /list, /help)
    if text.startswith("/"):
        cmd_response = await handle_bridge_command(text)
        if cmd_response is not None:
            await send_to_qq(reply_type, target_id, cmd_response)
            return web.json_response({"status": "ok", "command": True})

    if message_type == "group":
        prompt = f"[QQ群消息 来自 {sender_name}(QQ:{user_id})]\n{text}"
    else:
        prompt = f"[QQ私聊消息 来自 {sender_name}(QQ:{user_id})]\n{text}"

    async def process_and_reply():
        await send_to_qq(reply_type, target_id, "⚡ 已收到，正在处理...")
        t0 = time.time()
        reply = await call_hermes_session(prompt, PERSISTENT_SID)
        elapsed = time.time() - t0
        log.info(f"💬 Hermes replied in {elapsed:.1f}s: {reply[:100]}...")
        await send_to_qq(reply_type, target_id, reply)

    asyncio.create_task(process_and_reply())
    return web.json_response({"status": "ok"})

# ── Health ───────────────────────────────────────────────────────────────────

async def handle_health(request: web.Request) -> web.Response:
    return web.json_response({
        "status": "ok",
        "service": "napcat-hermes-bridge",
        "session": PERSISTENT_SID,
    })

# ── Main ─────────────────────────────────────────────────────────────────────

async def startup(app: web.Application):
    """Create a FRESH session on each chain startup (no cross-contamination)."""
    global PERSISTENT_SID
    log.info("Creating fresh session for this chain instance...")
    PERSISTENT_SID = await create_session()
    save_session_id(PERSISTENT_SID)
    log.info(f"🌉 NapCat ↔ Hermes Bridge v3 starting on {BRIDGE_HOST}:{BRIDGE_PORT}")
    log.info(f"   NapCat API: {NAPCAT_API}")
    log.info(f"   Hermes API: {HERMES_API}")
    log.info(f"   Session:    {PERSISTENT_SID}  (fresh)")
    log.info(f"   Owner QQ:   {ALLOWED_QQ}")
    log.info(f"   Commands:   /new /switch <id> /session /list /help")

def main():
    app = web.Application()
    app.on_startup.append(startup)
    app.router.add_post("/onebot", handle_onebot_event)
    app.router.add_get("/health", handle_health)
    web.run_app(app, host=BRIDGE_HOST, port=BRIDGE_PORT, print=None)

if __name__ == "__main__":
    main()
