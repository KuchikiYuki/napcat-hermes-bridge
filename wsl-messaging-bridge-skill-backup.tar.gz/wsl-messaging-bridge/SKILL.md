---
name: wsl-messaging-bridge
description: "Bridge messaging platforms to Hermes Agent in WSL via headless protocol adapters."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux]
tags: [wsl, messaging, napcat, qq, onebot, hermes-gateway, bridge]
metadata:
  hermes:
    tags: [wsl, messaging, napcat, qq, onebot, hermes-gateway, bridge]
    category: software-development
---

# WSL Messaging Bridge Skill

Connect a messaging platform (QQ via NapCat/OneBot, Telegram, Discord, etc.)
to a Hermes Agent instance running in WSL, using a lightweight HTTP bridge
script. The Hermes agent runs as a persistent background session via the API
Server gateway adapter; the bridge forwards inbound messages and relays
replies.

## When to Use

- User wants to send commands to Hermes from a phone messaging app (QQ, etc.).
- The messaging platform has no native Hermes gateway adapter (e.g. QQ via
  NapCat/OneBot v11 — Hermes has a `qqbot` adapter for the official Tencent
  API, but that's a different protocol).
- You need a headless Electron app (NTQQ) running in WSL with xvfb.
- User wants a one-click startup script that chains all services together.

## When NOT to Use

- **Do not use AstrBot as an intermediary.** AstrBot is a standalone LLM bot
  framework with its own model configuration — it is NOT a thin relay. Using
  it as a middle layer between NapCat and Hermes adds complexity without value:
  AstrBot would need its own LLM provider configured, creating a second agent
  that shadows the Hermes agent. The correct architecture is NapCat → Bridge →
  Hermes API Server, with no AstrBot in the loop.
- **Do not spawn a new Hermes session per message within a single chain run.**
  The user's requirement is a persistent mapping: one NapCat process ↔ one
  Hermes agent session that lives for the duration of a chain run. The bridge
  achieves this by calling `/api/sessions/{SID}/chat` with a persistent session
  ID stored in a file. A stateless API call (no session ID) would create a
  throwaway session per message, losing context and defeating the purpose.
- **Do create a FRESH session on each chain startup.** Reusing a hardcoded
  session ID across chain restarts risks cross-contamination with other agent
  processes (e.g. the TUI session) that may have claimed the same ID. Each
  `qq-start.sh` invocation should generate a new session ID using the Hermes
  TUI format (`YYYYMMDD_HHMMSS_6hex`, e.g. `20260629_153354_2d6137`), persist
  it to `current_session.txt`, and use it for all messages until the next chain
  restart or a `/new` command. The user can switch back to an old session with
  `/switch <id>` if desired. Using the TUI format (not a custom `qq_` prefix)
  ensures session IDs are visually consistent across TUI and bridge, and the
  short-hash display in the TUI sidebar matches what `/list` shows.
- **Do not hardcode session IDs.** The original v2 bridge hardcoded
  `api_1782539173_f78ea9ee` and skipped `ensure_session()` on startup. When the
  Hermes Gateway restarted or the session expired, the ID became stale — the
  `/chat` endpoint would silently create a new session with a different ID,
  causing the bridge to lose all context while still sending to the old ID.
  Always persist the session ID to a file and call `ensure_session()` on
  startup, or better yet create a fresh session each time.

## Prerequisites

- WSL2 with systemd enabled (`/etc/wsl.conf` → `[boot] systemd=true`).
- `sudo` available (for apt installs: xvfb, libnss3, etc.).
- A Windows-side HTTP proxy reachable from WSL (typically the WSL gateway IP,
  e.g. `<WSL_GATEWAY_IP>:<PROXY_PORT>`). See `references/wsl-proxy-setup.md`.
- Hermes installed and configured (`hermes config set` works).
- `uv` installed (`pip install uv` in a venv, or system-wide).

## Quick Reference

| Component | Port | Purpose |
|---|---|---|
| Hermes API Server | 8642 | OpenAI-compatible endpoint, runs the agent |
| Bridge script | 8080 | HTTP listener for platform events, relays to Hermes |
| NapCat WebUI | 6099 | QQ login / management panel |
| NapCat HTTP API | 3000 | OneBot v11 send_msg endpoint |

## Architecture

```
Phone QQ ──→ NTQQ (headless, xvfb) ──→ NapCat ──POST──→ Bridge (:8080)
                                                          │
Phone QQ ←── NapCat HTTP API (:3000) ←─── Bridge ←─── Hermes API (:8642)
```

- **NapCat** hooks into NTQQ's Electron entry point (`loadNapCat.js`) and
  exposes an OneBot v11 HTTP API + posts events to a webhook URL.
- **Bridge** is a small `aiohttp` server that receives OneBot events, calls
  Hermes API Server's `/api/sessions/{SID}/chat` endpoint with a persistent
  session ID (stored in `current_session.txt`), and sends the reply back via
  NapCat's HTTP API. A fresh session is created on each chain startup; the
  session ID persists for the lifetime of that chain run. QQ commands (`/new`,
  `/switch`, `/session`, `/list`, `/help`) allow the user to manage sessions
  from their phone.
- **Hermes API Server** is a gateway platform adapter (`platforms.api_server`)
  that runs the agent loop. All QQ messages within a chain run share a single
  session ID so the agent keeps full context across messages.

## Procedure

### 1. Install system dependencies

NTQQ is an Electron app and needs xvfb + several GUI libraries:

```bash
sudo apt-get -o Acquire::http::Proxy="" -o Acquire::https::Proxy="" install -y \
    xvfb unzip libnss3 libnotify4 libsecret-1-0 libgbm1 \
    libasound2t64 fonts-wqy-zenhei gnutls-bin libglib2.0-dev \
    libdbus-1-3 libgtk-3-0 libxss1 libxtst6 libatspi2.0-0 \
    libx11-xcb1 ffmpeg curl jq
```

> **Pitfall:** `libasound2` is a virtual package on Ubuntu 26.04+; use
> `libasound2t64` instead.

> **Pitfall:** If a stale proxy is configured system-wide (e.g.
> `198.18.0.1:7891` from a previous VPN), apt will fail to connect. Bypass
> with `-o Acquire::http::Proxy="" -o Acquire::https::Proxy=""`.

### 2. Download and extract NTQQ

NapCat requires a matching NTQQ version. Check the NapCat release notes for
the recommended QQ version, then download the Linux `.deb`:

```bash
mkdir -p ~/napcat-astrbot && cd ~/napcat-astrbot
# Set proxy for the download
export HTTP_PROXY="http://<WSL_GATEWAY>:<PORT>"
export HTTPS_PROXY="$HTTP_PROXY"

curl -L -o linuxqq.deb "https://dldir1v6.qq.com/qqfile/qq/QQNT/<hash>/linuxqq_<ver>_amd64.deb"
# Extract WITHOUT sudo — dpkg-deb -x works in user space
dpkg-deb -x linuxqq.deb ntqq/
```

### 3. Download NapCat and inject into NTQQ

```bash
curl -L -o NapCat.Shell.zip "https://github.com/NapNeko/NapCatQQ/releases/download/v<ver>/NapCat.Shell.zip"
unzip -q NapCat.Shell.zip -d napcat/

# Inject: point NTQQ's entry to NapCat
QQ_APP="ntqq/opt/QQ/resources/app"
cat > "$QQ_APP/loadNapCat.js" << EOF
(async () => {await import('file://$HOME/napcat-astrbot/napcat/napcat.mjs');})();
EOF

# Update NTQQ package.json main field
python3 -c "
import json; p='$QQ_APP/package.json'; f=open(p); d=json.load(f); f.close()
d['main']='./loadNapCat.js'; open(p,'w').write(json.dumps(d,indent=2))
"
```

> **Critical:** Use an **absolute path** in `loadNapCat.js`. The Docker image
> uses `file:///app/napcat/napcat.mjs`. Relative paths like `./napcat/napcat.mjs`
> fail because NTQQ resolves them relative to the QQ resources directory, not
> where NapCat's `node_modules` live.

> **Pitfall:** NapCat's `napcat.mjs` imports sibling files (`conout-*.js`)
> and `node_modules/` from its own directory. Keep all NapCat files together
> in `~/napcat-astrbot/napcat/` — do NOT split them into the NTQQ app dir.

> **Pitfall:** NapCat creates account-specific config overrides after first
> login. See `references/napcat-config.md` for the full file listing and
> how to update them.

### 4. Configure NapCat OneBot v11

Write `napcat/config/onebot11.json` with HTTP Server (for sending) + HTTP
Client (for receiving events):

```json
{
  "network": {
    "httpServers": [{
      "enable": true, "name": "api",
      "host": "127.0.0.1", "port": 3000,
      "messagePostFormat": "array", "token": "",
      "debug": false, "enableForcePushEvent": true
    }],
    "httpClients": [{
      "enable": true, "name": "bridge",
      "url": "http://127.0.0.1:8080/onebot",
      "messagePostFormat": "array", "reportSelfMessage": false, "token": ""
    }],
    "websocketServers": [], "websocketClients": [], "plugins": []
  },
  "musicSignUrl": "", "enableLocalFile2Url": false, "parseMultMsg": false
}
```

### 5. Enable Hermes API Server

```bash
hermes config set platforms.api_server.enabled true
hermes config set platforms.api_server.extra.key "<your-api-key>"
hermes config set platforms.api_server.extra.host "127.0.0.1"
hermes config set platforms.api_server.extra.port 8642
```

> If no key is set, auth is skipped (OK for localhost-only). The bridge uses
> `X-Hermes-Session-Key` header to maintain a single persistent agent session
> across all messages.

> See `references/hermes-api-session-endpoints.md` for the full API reference
> (create/get/list/chat endpoints, response formats, field semantics). These
> formats were discovered by probing with `curl` — they are not in the Hermes
> docs and are needed for bridge-level session management.

### 6. Write the bridge script

See `templates/bridge.py` for a ready-to-use aiohttp bridge (v3). Key
design points:

- **Fresh session on startup**: each chain startup creates a new session
  (`YYYYMMDD_HHMMSS_6hex` format matching Hermes TUI, e.g.
  `20260629_153354_2d6137`), persisted to `current_session.txt`. This
  prevents cross-contamination with other agent processes (TUI, etc.)
  that might claim the same session ID. Using the TUI format ensures
  consistency between what the user sees in the TUI sidebar and what
  `/list` returns from the bridge.
- **Session chat endpoint**: uses `/api/sessions/{SID}/chat` (not
  `/v1/chat/completions` with `X-Hermes-Session-Key`) — the sessions API
  endpoint provides explicit session lifecycle control.
- **404 auto-recovery**: if the session disappears mid-conversation (Gateway
  restart, session expiry), the bridge recreates the session with
  `ensure_session()` and retries the chat call once.
- **QQ bridge commands**: messages starting with `/` are intercepted before
  reaching Hermes:
  - `/new` — create a new session (clears context)
  - `/switch <id>` — switch to an existing session
  - `/session` — show current session ID
  - `/list` — list all Hermes sessions
  - `/help` — show command help
- **User whitelist**: filter messages by QQ ID so only the owner can command
  the agent.
- **Async fire-and-forget**: respond to NapCat's POST immediately (200 OK),
  process the Hermes call in `asyncio.create_task()` so NapCat doesn't
  timeout. An instant ACK ("⚡ 已收到，正在处理...") is sent to QQ before
  the Hermes call begins.

### 7. Write one-click startup/stop scripts

See `templates/qq-start.sh.template` and `templates/qq-stop.sh.template`.
The startup order is: Hermes Gateway → Bridge → NapCat. Each waits for its
port to be listening before proceeding.

### 8. Launch — quick login + QR fallback

```bash
bash ~/napcat-astrbot/qq-start.sh
```

The script starts NapCat with `-q <QQ_BOT_ACCOUNT>` for **quick login** using
stored credentials — this skips the QR code entirely if tokens are still
valid (typically ~15s to login). If tokens have expired, NapCat falls back to
QR scan mode automatically.

NapCat generates a QR code at `napcat/cache/qrcode.png`. The startup script
copies it to the Windows Desktop for easy scanning:

```bash
cp ~/napcat-astrbot/napcat/cache/qrcode.png /mnt/c/Users/<user>/Desktop/
```

After scanning with phone QQ, port 3000 comes up and the bridge starts
receiving events. The script detects port 3000 and automatically sends a
confirmation message to the owner's QQ.

> **Quick login (`-q`):** After the first successful QR scan, NTQQ stores
> login tokens in `~/.config/QQ/`. Subsequent restarts with `-q <QQID>` will
> auto-login in ~15s without any scan. Tokens can expire — if NapCat shows
> `Login Error, ErrType: 1, ErrCode: 3`, it falls back to QR mode.

> **QR expiry:** NapCat QR codes expire after ~2 minutes. The startup script
> detects refreshed QR codes (by file timestamp) and re-copies them to the
> Desktop automatically. If scanning fails, just wait for the next one.

## Pitfalls

### 0. NapCat account-specific config shadows onebot11.json

When NapCat logs in with a QQ account, it creates per-account config files
like `onebot11_<QQID>.json` in `napcat/config/`. These **override** the
generic `onebot11.json`. If you change `onebot11.json` after the first login,
NapCat will ignore it and load the stale account-specific copy.

**Fix:** After changing the OneBot config, also overwrite the account-specific
file:

```bash
cp napcat/config/onebot11.json napcat/config/onebot11_<QQID>.json
```

Then restart NapCat. The account-specific filename pattern is
`onebot11_<QQ_number>.json` (e.g. `onebot11_<YOUR_BOT_QQ>.json`).

### 1. NTQQ/NapCat proxy interception of localhost

If `HTTP_PROXY`/`http_proxy` env vars are set, curl and aiohttp will route
`127.0.0.1` requests through the proxy, getting 502 Bad Gateway. Always set
`NO_PROXY="127.0.0.1,localhost"` or use `--noproxy '*'` with curl when
accessing local services.

**Critical:** NapCat's internal Node.js HTTP client (the `httpClients` config
that POSTs OneBot events to the bridge) **also respects `HTTP_PROXY`** — but
`env -u HTTP_PROXY` alone is NOT sufficient. Even after unsetting the env var
from the child process, NapCat's Node.js runtime may still pick up proxy
settings from other sources (system configs, DNS-level TUN interception by
Clash/VPN).

**Fix (proven in production):** Both unset the proxy vars AND explicitly set
`NO_PROXY` in the child environment:

```bash
env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy \
    NO_PROXY="127.0.0.1,localhost,::1" no_proxy="127.0.0.1,localhost,::1" \
    xvfb-run -a ntqq/opt/QQ/qq --no-sandbox ...
```

Set `NO_PROXY` in BOTH uppercase and lowercase (Node.js checks lowercase
`no_proxy` on some platforms). Without this, NapCat silently routes event
POSTs through the VPN's TUN-mode fake-IP DNS (`198.18.0.x`), getting 502
Bad Gateway — no error in NapCat logs, bridge never receives events.

### 2. NapCat file layout — absolute vs relative paths

The Docker entrypoint copies NapCat to `/app/napcat/` and uses an absolute
`file:///app/napcat/napcat.mjs` in `loadNapCat.js`. If you try to use a
relative `./napcat/napcat.mjs`, NTQQ resolves it relative to
`resources/app/` and fails with `ERR_MODULE_NOT_FOUND`. Always use the full
absolute path.

### 3. PyPI mirrors in China return 403 on wheel downloads

Tsinghua/aliyun PyPI mirrors may return 200 on the simple index but 403 on
actual `.whl` downloads. If `uv tool install` fails with 403, switch to
`--index-url "https://pypi.org/simple"` and route through the proxy.

### 4. apt stale proxy config

WSL may have a leftover proxy at `198.18.0.1:7891` from a previous VPN
session. `apt-get update` fails with "Connection refused." Fix: pass
`-o Acquire::http::Proxy="" -o Acquire::https::Proxy=""` to bypass.

### 5. xvfb authorization

Running `ntqq/opt/QQ/qq` directly with `DISPLAY=:99` fails with "Authorization
required, but no authorization protocol specified." Always use `xvfb-run -a`
which sets up the X authority file automatically.

### 6. nohup backgrounding blocked by Hermes terminal tool

The Hermes `terminal` tool rejects shell-level `&` / `nohup` / `setsid`
backgrounding in foreground mode. Use `terminal(background=true)` to start
long-lived processes, or write a startup script that uses `nohup ... &`
internally and run that script in foreground.

### 7. NapCat config directory location

NapCat looks for `onebot11.json`, `webui.json`, and `napcat.json` in its own
`config/` subdirectory (e.g. `~/napcat-astrbot/napcat/config/`), NOT in the
NTQQ resources directory. Placing configs in the wrong location means NapCat
loads with defaults and the OneBot network config is silently ignored.

### 8. Session ID becomes stale after Gateway restart (silent context loss)

**Symptom:** The user reports that Hermes "loses memory" mid-conversation —
the agent starts a new session even though the bridge is using the same
session ID.

**Root cause:** The bridge uses a hardcoded session ID (e.g.
`api_1782539173_f78ea9ee`). When the Hermes Gateway restarts or the session
expires, the ID becomes stale. The `/api/sessions/{SID}/chat` endpoint may
silently create a new session with a different internal ID, while the bridge
continues sending to the old ID. The bridge has no idea this happened.

**Fix (v3 bridge):**
1. Never hardcode session IDs — generate a fresh one on each chain startup.
2. Persist the session ID to a file (`current_session.txt`).
3. On 404 from `/api/sessions/{SID}/chat`, call `ensure_session()` to recreate
   the session with the same ID, then retry the chat call once.
4. Provide QQ commands (`/new`, `/switch`, `/session`, `/list`) so the user
   can manually manage sessions from their phone.

### 9. NapCat GPU process crash on startup (FATAL: GPU process isn't usable)

**Symptom:** NapCat starts, logs in successfully, sends the confirmation
message — then crashes ~1 minute later with:
```
ERROR:content/browser/gpu/gpu_process_host.cc:951] GPU process launch failed: error_code=1002
FATAL:content/browser/gpu/gpu_data_manager_impl_private.cc:415] GPU process isn't usable. Goodbye.
```

**Root cause:** NTQQ is an Electron app. Even with `--disable-gpu
--disable-software-rasterizer` flags, the Electron zygote still tries to
spawn a GPU child process. On WSL2 without a real GPU, this fails 3 times
and Electron's GPU data manager calls `FATAL` — killing the entire NTQQ
process, which takes NapCat down with it.

**Fix (proven in production):** `--disable-gpu` alone is NOT sufficient.
Add `--disable-zygote --in-process-gpu` to prevent the zygote from
spawning GPU children and force GPU work in-process:
```bash
xvfb-run -a ntqq/opt/QQ/qq \
    --no-sandbox --disable-gpu --disable-software-rasterizer \
    --disable-zygote --in-process-gpu \
    -q "$QQ_BOT"
```
This combination has been tested and confirmed stable on WSL2 Ubuntu 26.04
with NTQQ headless + xvfb. `--use-gl=swiftshader` is an alternative but
adds software rendering overhead; `--in-process-gpu` is lighter.

> **Note:** This crash happens AFTER successful login and message sending,
> so the bridge appears to work for ~1 minute before dying. Always check
> `napcat.log` for FATAL errors if the chain stops working shortly after
> startup.

### 10. Hermes API response format mismatch (/list returns empty)

**Symptom:** The `/list` QQ command returns "没有找到会话列表" even though
sessions exist.

**Root cause:** The Hermes Gateway `/api/sessions` endpoint returns:
```json
{"object": "list", "data": [...]}
```
NOT `{"sessions": [...]}` or a bare array. If `list_sessions()` tries to
extract `data.get("sessions", [])`, it gets an empty list.

**Fix:** Parse the `data` key from the response:
```python
sessions = data.get("data") or data.get("sessions") or []
```
The `data.get("data")` fallback handles the actual API format; the
`data.get("sessions")` fallback is kept for forward-compat in case the
API changes.

### 11. Startup confirmation message should include Session ID

When the chain starts, the confirmation QQ message should include the
current session ID (read from `current_session.txt`) and list available
bridge commands. This helps the user verify the session was created and
knows how to manage it remotely:

```bash
session_id=$(cat "$BASE_DIR/current_session.txt" 2>/dev/null | head -1 | tr -d '[:space:]')
if [ -n "$session_id" ]; then
    confirm_msg="🌉 NapCat ↔ Hermes 桥接已上线！...\\n\\n📌 当前会话: $session_id\\n\\n指令: /new /switch <id> /session /list /help"
fi
```

> **Note:** The `current_session.txt` file is written by the bridge on
> startup. There is a brief race window between bridge startup and the
> confirmation message being sent. The startup script reads the file
> AFTER detecting port 3000 (NapCat login), which gives the bridge enough
> time to have written it.

### 12. Do not read all Hermes internal source files when debugging

When investigating Hermes Gateway or API behavior, do NOT attempt to read
all internal source files (gateway/*.py, agent/*.py, etc.). This will
rapidly overflow the agent's context window. Instead:

- Use `curl` to probe the API endpoints directly and observe response
  formats.
- `grep -n` for specific keywords (e.g. `session`, `chat`, `id`) in
  specific files — never `cat` entire modules.
- Read only the bridge script (`bridge.py`) and the startup script
  (`qq-start.sh`) in full; these are small and contain the relevant
  logic. The Hermes internals are not needed to debug bridge-level
  session management issues.

### 13. NapCat `-q` quick login parameter is easy to miss

**Symptom:** Every chain restart requires a QR code scan, even though
NapCat was previously logged in successfully. The user expects automatic
login but gets a QR code every time.

**Root cause:** NapCat supports a `-q <QQID>` command-line flag for
**quick login** — it reuses stored login credentials from
`~/.config/QQ/` to auto-login in ~15 seconds without scanning a QR
code. Without `-q`, NapCat defaults to QR scan mode every time. The
parameter is documented in NapCat's CLI help but not prominently in
the Wiki, making it easy to miss during initial deployment.

**Fix:** Always pass `-q <QQ_BOT_ACCOUNT>` in the NapCat launch command:
```bash
xvfb-run -a ntqq/opt/QQ/qq \
    --no-sandbox --disable-gpu --disable-software-rasterizer \
    --disable-zygote --in-process-gpu \
    -q "$QQ_BOT"
```

After the first successful QR scan, NTQQ stores login tokens in
`~/.config/QQ/`. Subsequent restarts with `-q` auto-login in ~15s. If
tokens have expired, NapCat automatically falls back to QR scan mode —
no manual intervention needed.

> **Pitfall within a pitfall:** The `-q` flag requires the QQ account
> to have been previously logged in on this machine. On a fresh install
> (no `~/.config/QQ/` directory), `-q` silently falls back to QR mode
> without warning — this is expected behavior, not a bug. The first
> startup will always require a QR scan; subsequent startups use `-q`.

## Verification

After startup, verify all four ports are listening:

```bash
ss -tlnp | grep -E '(8642|8080|3000|6099)'
```

Test the Hermes API directly:

```bash
curl --noproxy '*' -s http://127.0.0.1:8642/health
# Should return: {"status": "ok", "platform": "hermes-agent", ...}
```

Check bridge health (includes current session ID):

```bash
curl --noproxy '*' -s http://127.0.0.1:8080/health
# Should return: {"status": "ok", "service": "napcat-hermes-bridge", "session": "qq_..."}
```

Check bridge logs for incoming messages:

```bash
tail -f ~/napcat-astrbot/logs/bridge.log
```

Send a test message from phone QQ → bridge log should show `📨 ...`,
followed by `💬 Hermes replied in Xs: ...`.

Test bridge commands from QQ:
- `/help` → should list all commands
- `/session` → should show current session ID (TUI format: `YYYYMMDD_HHMMSS_6hex`)
- `/list` → should list all Hermes sessions (if empty, check API response format — see pitfall #10)

Verify session ID format matches TUI:
```bash
cat ~/napcat-astrbot/current_session.txt
# Should look like: 20260629_153354_2d6137 (NOT qq_1782718237_fcbb8013)
```

Verify API response format for `/list`:
```bash
curl --noproxy '*' -s -H "Authorization: Bearer <KEY>" http://127.0.0.1:8642/api/sessions | python3 -m json.tool | head -5
# Should show {"object": "list", "data": [...]}
```

Check for NapCat GPU crash (pitfall #9):

```bash
grep -i 'FATAL\|GPU process' ~/napcat-astrbot/logs/napcat.log
# If found, add --disable-zygote --in-process-gpu to qq-start.sh NapCat launch flags
```
